// [INPUT] 无
// [OUTPUT] OrientationCaptureView组件的导出
// [POS] 特征层OrientationCapture模块的入口文件, 提供组件的统一导出
export { OrientationCaptureView } from './OrientationCaptureView';

