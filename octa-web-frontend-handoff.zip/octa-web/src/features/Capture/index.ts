// [INPUT] 无
// [OUTPUT] CaptureView组件的导出
// [POS] 特征层Capture模块的入口文件, 提供组件的统一导出
export { CaptureView } from './CaptureView';

