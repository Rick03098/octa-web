// [INPUT] ChatIntroView组件
// [OUTPUT] 导出ChatIntroView组件
// [POS] 特征层对话开启页面的入口文件, 提供组件导出
export { ChatIntroView } from './ChatIntroView';

