// [INPUT] ChatView组件
// [OUTPUT] 导出ChatView组件
// [POS] 特征层对话页面的入口文件, 提供组件导出
export { ChatView } from './ChatView';

