// [INPUT] 无
// [OUTPUT] CaptureCompleteView组件的导出
// [POS] 特征层CaptureComplete模块的入口文件, 提供组件的统一导出
export { CaptureCompleteView } from './CaptureCompleteView';

