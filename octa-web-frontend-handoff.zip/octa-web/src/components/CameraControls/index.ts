// [INPUT] 无
// [OUTPUT] CameraControls组件的导出
// [POS] 组件层CameraControls模块的入口文件, 提供组件的统一导出
export { FlashButton } from './FlashButton';
export { ShutterButton } from './ShutterButton';

