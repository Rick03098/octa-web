// [INPUT] LottieAnimation组件
// [OUTPUT] 统一导出LottieAnimation组件, 简化导入路径
// [POS] 组件层的入口文件, 统一导出LottieAnimation组件
export { default } from './LottieAnimation';

